import { parseFlags } from '@/lib/utils';
import { GymType, NS } from '@ns';

interface Flags {
  str: boolean;
  def: boolean;
  dex: boolean;
  agi: boolean;
  period: number;
  step: number;
  _: string[];
}

const FLAGS: [keyof Flags, Flags[keyof Flags]][] = [
  ['str', false],
  ['def', false],
  ['dex', false],
  ['agi', false],
  ['period', 10000],
  ['step', 10],
];

export async function train(ns: NS, sleeveNumbers: number[], final: number, flags: Flags) {
  const actions = Object.fromEntries(sleeveNumbers.map((sn) => [sn, 'none']));
  const targets = Object.fromEntries(sleeveNumbers.map((sn) => [sn, flags.step]));
  while (true) {
    for (const sleeveNumber of sleeveNumbers) {
      const {
        skills: { strength, defense, dexterity, agility },
      } = ns.sleeve.getSleeve(sleeveNumber);

      const stats = [
        { stat: strength, doStat: flags.str, name: 'str' as GymType },
        { stat: defense, doStat: flags.def, name: 'def' as GymType },
        { stat: dexterity, doStat: flags.dex, name: 'dex' as GymType },
        { stat: agility, doStat: flags.agi, name: 'agi' as GymType },
      ];

      const isTraining = stats.some(({ stat, doStat, name }) => {
        if (doStat && stat < targets[sleeveNumber]) {
          if (actions[sleeveNumber] !== name && ns.sleeve.setToGymWorkout(sleeveNumber, 'Powerhouse Gym', name)) {
            actions[sleeveNumber] = name;
          }
          return true;
        }
        return false;
      });

      if (!isTraining) {
        if (targets[sleeveNumber] < final) {
          targets[sleeveNumber] += flags.step;
          await ns.sleep(0);
          continue;
        }
        ns.toast('Finished training.');
        ns.sleeve.setToIdle(sleeveNumber);
        return;
      }
    }
    await ns.sleep(flags.period);
  }
}

export async function main(ns: NS): Promise<void> {
  const flags = parseFlags<Flags, 'sleeveNumbers' | 'final'>(ns, FLAGS, ['sleeveNumbers', 'final']);
  const sleeveNumbers = String(flags.sleeveNumbers)
    .split(',')
    .map((sn) => Number(sn));
  await train(ns, sleeveNumbers, Number(flags.final), flags);
}

import { FactionName, FactionWorkType, NS } from '@ns';

export async function main(ns: NS): Promise<void> {
  const faction = ns.args.at(0) as FactionName | undefined;
  const workType = ns.args.at(1) as FactionWorkType | undefined;
  const sns = ns.args.at(2) as string | undefined;
  if (faction === undefined || workType === undefined || sns === undefined) {
    ns.tprint(`usage: run ${ns.getScriptName()} <faction> <sleeve numbers>`);
    ns.exit();
  }

  const sleeveNumbers = sns.split(',').map(Number);
  for (const sn of sleeveNumbers) {
    ns.sleeve.setToFactionWork(sn, faction, workType);
  }
}
